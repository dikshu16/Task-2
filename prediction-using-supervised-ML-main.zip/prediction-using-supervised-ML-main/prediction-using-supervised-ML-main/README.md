# prediction-using-supervised-ML

dataset used
http://bit.ly/w-data
